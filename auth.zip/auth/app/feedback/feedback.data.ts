import { Feedback } from "./feedback.type";

  // export const feedbacks: Feedback[] = [
  //   { userid: 1, resid: 1, rating: 4, feedbackText: "Lovely ambience and delicious food!" },
  //   { userid: 2, resid: 1, rating: 5, feedbackText: "Excellent service and great atmosphere." },
  //   { userid: 3, resid: 2, rating: 3, feedbackText: "Good food but a bit too spicy for my taste." },
  //   { userid: 4, resid: 2, rating: 4, feedbackText: "Friendly staff and perfectly cooked steaks." },
  //   { userid: 5, resid: 3, rating: 5, feedbackText: "Amazing seafood varieties and breathtaking view!" },
 
  // ];

export const feedbacks : Feedback[] = [

]