type Feedback = {
    userid: number;
    username?: string; 
    rating: number;
    feedbackeach: string;
};

export interface RESDATA{
    resid:number;
    resimg:string;
    resname:string;
    resdesc:string;
  
}   