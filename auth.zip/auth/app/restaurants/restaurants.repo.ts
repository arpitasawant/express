// // import { UserModel } from "./user.schema";
// // import { User } from "./user.types";

// // const find = (query: Partial<User>) => UserModel.find(query)

// // const findOne = (query: Partial<User>) => UserModel.findOne(query)

// // const insertOne = (query: User) => UserModel.insertOne(query)

// // export default {
// //     find, findOne, insertOne
// // }


// import { UserModel } from "./user.schema";
// import { User } from "./user.types";

// const find = (query: Partial<User>) => UserModel.find(query)

// const findOne = (query: Partial<User>) => UserModel.findOne(query)
